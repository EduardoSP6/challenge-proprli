---
title: v6
slogan: Easily build Eloquent queries from API requests.
githubUrl: https://github.com/spatie/laravel-query-builder
branch: main
---
