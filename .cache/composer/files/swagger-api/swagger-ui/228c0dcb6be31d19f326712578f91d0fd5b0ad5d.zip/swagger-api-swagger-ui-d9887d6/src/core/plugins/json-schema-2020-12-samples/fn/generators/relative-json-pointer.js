/**
 * @prettier
 */
const relativeJsonPointerGenerator = () => "1/0"

export default relativeJsonPointerGenerator
